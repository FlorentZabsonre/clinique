<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="fr" xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Language" content="fr" />
<title>Page Agent</title>
<link rel="stylesheet" type="text/css" href="0Accueil.css" />
<link rel="shortcut icon" type="image/x-icon" href="VW.ico" />

</head>
<body>
	<div class="arriereplan"></div>
	<div id="titre">
		<div class="logo"><a href="http://www.volkswagen.fr"><img src="VW.jpg"></a></div>
		<div class="Accueil"><a class="link" href='Agent.php'>Accueil</a></div>
		<div class="LieuxHoraires">Lieux et horaires</div>
		<div class="Tarifs"><a class="link" href='pageActes.php'>Tarifs</a></div>
		<div class="Evenements">Evenements</div>
		<div class="Contact">Contact</div>
		<div class="deconnexion"><a class="link" href="Accueil.php">Déconnexion</a></div>
		<!--<div class="Connexion"><a class="link" href='Connexion.php'>Connexion</a></div>-->
	</div>
	<div id="menu">
		<div class="pagePatient"><a class="link" href='inscriptionPatient.php'>Page Patients</a></div>
	</div>
	<!--<div id="colonnes">
		<div id="col1"></div>
		<div id="col2"></div>
		<div id="col3"></div>
	</div>
	<div class="bas">Copyright : tous droits réservés.</div>-->
</body>
</html>